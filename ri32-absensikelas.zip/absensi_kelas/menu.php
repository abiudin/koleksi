<?php include "cek_session.php"; ?>
<ul>
	<li>
		<h2>MENU UTAMA</h2>
		<ul>
			<li><a href="?page=home">Home</a></li>
			<li><a href="?page=kelas">Kelas</a></li>
			<li><a href="?page=siswa">Siswa</a></li>
			<li><a href="?page=absensi">Absensi</a></li>
			<li><a href="?page=rekap_absensi">Rekap</a></li>
		</ul>
	</li>
</ul>
