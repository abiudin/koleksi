<?php include "cek_session.php"; ?>
<div class="post">
	<h2 class="title"><a href="#">Selamat Datang </a></h2>
	<p class="meta"><em>Sunday, April 26, 2009 7:27 AM Posted by <a href="#">Someone</a></em></p>
	<div class="entry">
		<p>Selamat datang di template web. semoga bermanfaat untuk anda semua :) </p>
	</div>
</div>

